module.exports.x=5;
module.exports.mostrarmensaje = function (){
    return 'holamundo,function de un módulo'
}